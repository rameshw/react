var express = require('express');
var router = express.Router();
var fs = require('fs');
 
router.get('/au', function(req, res, next) {

	// fs.readFile('./testFile.txt', 'utf8', function(err, contents) {
	//     //console.log(contents);
 //      results="hello everybody !";
 //      res.send(JSON.stringify(results));
	// });
	 res.json([{
    id: 1,
    username: "samsepi0l"
  }, {
    id: 2,
    username: "D0loresH4ze"
  }]);
	console.log('after calling readFile');

});

module.exports = router;


