import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class FlavorForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: 'au'};

    this.handleChange = this.handleChange.bind(this);
    this.handleUAT = this.handleUAT.bind(this);
    this.handlePILOT = this.handlePILOT.bind(this);
    this.handlePROD = this.handlePROD.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
  }

  handleUAT(event) {
    alert('Your favorite flavor is: ' + this.state.value);
    event.preventDefault();
  }

handlePILOT(event) {
    alert('Your favorite flavor is: ' + this.state.value);
    event.preventDefault();
  }

  handlePROD(event) {
    alert('Your favorite flavor is: ' + this.state.value);
    event.preventDefault();
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>
          Market:
          <select value={this.state.value} onChange={this.handleChange}>
            <option value="au">AU</option>
            <option value="hkcn">HK & CN</option>
            <option value="hk">HK</option>
            <option value="cn">CN</option>
            <option value="kr">KR</option>
            <option value="tw">TW</option>
          </select>
        </label>
        <AimTable className="aimtable" value={this.state.value}/>
        <button className="uat" onClick={this.handleUAT} >Deploy UAT</button>
        <button className="pilot" onClick={this.handlePILOT} >PILOT</button>
        <button className="prod" onClick={this.handlePROD} >PROD</button>
      </form>
    );
  }
}

class AimTable extends Component {
  state = {au: []}

  componentDidMount() {
    fetch('/au')
      .then(res => res.json())
      .then(au => this.setState({ au }));
  }

render() {
  
    return (
<table> 
<tbody>
<tr>
    <th>Link</th>
    <th>{this.props.value}_uat</th> 
    <th>{this.props.value}_pilot</th>
    <th>{this.props.value}_prod</th>
  </tr>
  <tr>
    <td>abc</td>
    <td>50</td> 
    <td>50</td>
     <td>50</td>
  </tr>
  <tr>
    <td>efg</td>
    <td>50</td> 
    <td>94</td>
     <td>50</td>
  </tr>
  </tbody>
  </table>

      );
  }

 }

       //   <h1>Users</h1>
      //   {this.state.users.map(user =>
      //     <div key={user.id}>{user.username}</div>
      //   )}
  
class App extends Component {



  render() {
    return (
      <div className="App">
      <FlavorForm className="myForm"/>

       </div>
    );
  }
}

export default App;
