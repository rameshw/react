import React, {Component} from 'react';
import ReleaseDiv from './ReleaseDiv';
import Other from './Other';

export default class Content extends Component {
    constructor(props) {
      super(props);
      this.state = {value: 'dashboard'};
    }

    createContent = (value) => {
        let data = [];
        // data.push(<SideBar />);
        if (value === 'other') {
            data.push(<ReleaseDiv/>);
        } else {
            data.push(<Other/>);
        }
        return data;
    }

    render(){
        const value = this.props.value;
        return (
            <div className="content-wrapper">
                {this.createContent(value)}
            </div>
        );
        
    }
}