  import React, { Component } from 'react';
  // import {Table} from 'react-bootstrap';
  // import './App.css';

  

  export default class Other extends Component {
    render() {
      return (
        
                <section className="content-header">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="box">
                                <div className="box-header with-border">
                                    <h3 className="box-title">Others</h3>
                                </div>
                                <div className="box-body">
                                    <div className="row">
                                        <div className="col-md-8">
                                       
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
          
      );
    }
  }

