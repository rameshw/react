import React, {Component} from 'react';
import Content from './Content';
import Header from './Header';

export default class SideBar extends Component {

    constructor(props) {
      super(props);
      this.state = {clicked: 'dashboard'};

      this.handleOther = this.handleOther.bind(this);
      this.handleDashboard = this.handleDashboard.bind(this);
    }

handleDashboard(event) {
    this.setState({clicked: 'dashboard'});
}

handleOther(event) {
    this.setState({clicked: 'other'});
}
    render(){
        return (
            <div class="wrapper">
            <Header />
            <aside className="main-sidebar">
                <section className="sidebar">
        
                    <form action="#" method="get" className="sidebar-form">
                        <div className="input-group">
                        <input type="text" name="q" className="form-control" placeholder="Search..." />
                        <span className="input-group-btn">
                                <button type="submit" name="search" id="search-btn" className="btn btn-flat"><i className="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                    </form>
                    <ul className="sidebar-menu" data-widget="tree">
                        <li className="header">NAVIGATION</li>
                        <li className="treeview">
                            <a href="#" onClick={this.handleDashboard}>
                                <i class="fa fa-dashboard"></i>
                                <span>Release Prep</span>
                            </a>
                            
                        </li>
                        <li className="treeview">
                            <a href="#" onClick={this.handleOther}>
                                <i className="fa fa-files-o"></i>
                                <span>Other</span>
                            </a>
                            
                        </li>

           
                    </ul>
                </section>
            </aside> 

            <Content value={this.state.clicked} />
            </div>

        )
    }
}
