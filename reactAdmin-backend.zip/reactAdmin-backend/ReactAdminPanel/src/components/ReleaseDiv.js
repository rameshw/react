  import React, { Component } from 'react';
  // import {Table} from 'react-bootstrap';
  // import './App.css';

  class FlavorForm extends React.Component {
    constructor(props) {
      super(props);
      this.state = {value: 'au'};

      this.handleChange = this.handleChange.bind(this);
      this.handleUAT = this.handleUAT.bind(this);
      this.handlePILOT = this.handlePILOT.bind(this);
      this.handlePROD = this.handlePROD.bind(this);
    }

    handleChange(event) {
      this.setState({value: event.target.value});
    }

    handleUAT(event) {
      alert('Your favorite flavor is: ' + this.state.value);
      event.preventDefault();
    }

  handlePILOT(event) {
      alert('Your favorite flavor is: ' + this.state.value);
      event.preventDefault();
    }

    handlePROD(event) {
      alert('Your favorite flavor is: ' + this.state.value);
      event.preventDefault();
    }

    render() {
      return (
        <form onSubmit={this.handleSubmit}>
          <label>
            Market: <select class="form-control" value={this.state.value} onChange={this.handleChange}>
            <option value=""></option>
              <option value="au">AU</option>
              <option value="hkcn">HK & CN</option>
              <option value="hk">HK</option>
              <option value="cn">CN</option>
              <option value="kr">KR</option>
              <option value="tw">TW</option>
            </select>
          </label>
          <div>.</div>
          <AimTable className="aimtable" value={this.state.value}/>
          <div>.</div>
          <button type="button" class="btn btn-block btn-primary"  onClick={this.handleUAT} >Deploy UAT</button>
          <button type="button" class="btn btn-block btn-info"  onClick={this.handlePILOT} >PILOT</button>
          <button type="button" class="btn btn-block btn-success"  onClick={this.handlePROD} >PROD</button>
        </form>
      );
    }
  }

  class AimTable extends Component {
    state = {
      links: [],
      prevMarket: ""
    }

    componentDidMount(){
      this.setState({prevMarket: this.props.value});
      fetch('/users?market=' + this.props.value)
        .then(res => res.json())
        .then(links => {
          console.log(this.state.currMarket + "_" + this.props.value);
          this.setState({ 
           links: links
         });
          console.log(this.state.links);
        });   
    }

    componentWillReceiveProps(nextProps) {
      if (this.props.value !== nextProps.value) {
      fetch('/users?market=' + nextProps.value)
        .then(res => res.json())
        .then(links => {
          console.log(this.props.value + "_" + nextProps.value);
          this.setState({ 
           links: links
         });
          console.log(this.state.links);
        });   
      }
    }

    createTable = (links) => {
        let table = [];
        for (let i = 0; i < links.length; i++) {
          let children = [];
          var link = this.state.links[i];
          children.push(<td>{link.name}</td>);

          //get full list of versions for each link
          children.push(<td>
            <select class="form-control" value={link.uat}>
              <option value={link.uat}>{link.uat}</option>
            </select>
          </td>);

          children.push(<td>{link.pilot}</td>);
          children.push(<td>{link.prod}</td>);
          table.push(<tr>{children}</tr>);
        }
        return table;
    }

  render() {
    const {links} = this.state;
    const uat = this.props.value + "_uat";
    const pilot = this.props.value + "_pilot";
    const prod = this.props.value + "_prod";

      return (
  <table class="table table-hover"> 
  <thead>
  <tr>
      <th>Link</th>
      <th>{uat}</th> 
      <th>{pilot}</th>
      <th>{prod}</th>
    </tr>
    </thead>
    <tbody>
    {this.createTable(links)}
    </tbody>
   </table>
        );
    }
   }

  export default class ReleaseDiv extends Component {
    render() {
      return (
         
        
                <section className="content-header">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="box">
                                <div className="box-header with-border">
                                    <h3 className="box-title">Dashboard</h3>
                                </div>
                                <div className="box-body">
                                    <div className="row">
                                        <div className="col-md-8">
                                            <FlavorForm className="myForm"/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            
    
      );
    }
  }

